public interface formatter<T> {

	public String voidformatter(T value);

}

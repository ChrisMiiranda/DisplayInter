public class display<T> {

	public show() {

	}

}

package com.christopher.calendario;

import com.christopher.display.formatter;

public class CalenFormatter implements Formatter<Calendario> {

	/**
	 * @see com.christopher.display.formatter#voidformatter(com.christopher.display.T)
	 * 
	 *  
	 */
	public String formatter(Calendario calendario) {
		return String.format("%d/%d/%d", calendario.getDia(), calendario.getMes(), calendario.getAno());
	}

}

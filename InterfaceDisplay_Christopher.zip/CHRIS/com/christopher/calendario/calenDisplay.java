package com.christopher.calendario;

import com.christopher.display.display;

public class CalenDisplay extends Display<Calendario> {
	private CalenFormatter cFormatter = new CalenFormatter();

	private Calendario calendario;
	
	//construtor
	public CalenDisplay() {
		this.calendario = new Calendario();
		this.calendario.setDia(06);
		this.calendario.setMes(07);
		this.calendario.setAno(2019);
	}
	
	public void show() {
		System.out.println(cFormatter.formatter(calendario));
	}
	

}


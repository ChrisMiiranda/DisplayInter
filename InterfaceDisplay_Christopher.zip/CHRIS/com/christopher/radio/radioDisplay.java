package com.christopher.radiofm;

import com.christopher.display.display;

public class RadioDisplay extends Display<Radio> {
	private RadioFormatter cFormatter = new RadioFormatter();

	private Radio radio;
	
	//construtor
	public RadioDisplay() {
		this.Radio = new Radio();
		this.Radio.setEstacao(105.07);
	}
	
	public void show() {
		System.out.println(cFormatter.formatter(radio));
	}
	

}

public class radiofm {

    private double estacao;
    
	public double getEstacao() {
		return estacao;
	}

	public setEstacao(double estacao) {
        this.estacao = estacao;
	}

}

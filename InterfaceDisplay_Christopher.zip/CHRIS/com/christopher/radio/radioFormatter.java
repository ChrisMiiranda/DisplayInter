package com.christopher.radiofm;

import com.christopher.display.formatter;

public class CalendFormatter implements Formatter<Radio> {

	/**
	 * @see com.christopher.display.formatter#voidformatter(com.christopher.display.T)
	 * 
	 *  
	 */
	public String formatter(Radio radio) {
		return String.format("%.2f", radio.getEstacao());
	}

}


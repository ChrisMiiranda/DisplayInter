package com.christopher.relogio;

import com.christopher.display.formatter;

public class RelogioFormatter implements Formatter<Relogio> {

	/**
	 * @see com.christopher.display.formatter#voidformatter(com.christopher.display.T)
	 * 
	 *  
	 */
	public String formatter(Relogio relogio) {
		return String.format("%tR", relogio.getHora(), relogio.getMinuto());
	}

}

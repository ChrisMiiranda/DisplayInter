package com.christopher.relogio;

import com.christopher.display.display;

public class RelogioDisplay extends Display<Relogio> {
	private RelogioFormatter cFormatter = new RelogioFormatter();

	private Relogio relogio;
	
	//construtor
	public RelogioDisplay() {
		this.relogio = new Relogio();
		this.relogio.setHora(14);
		this.relogio.setMinuto(07);
	}
	
	public void show() {
		System.out.println(cFormatter.formatter(relogio));
	}
	

}


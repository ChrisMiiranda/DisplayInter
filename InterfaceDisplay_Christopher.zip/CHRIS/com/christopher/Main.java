import com.christopher.relogio.relogio;
import com.christopher.temperatura.temperatura;
import com.christopher.calendario.Calendario;
import com.christopher.radiofm.radio;

public class Main{
    public static void main(String[] args) {
        Calendario c1 = new Calendario();
            c1.setDia(dia);
            c1.setMes(mes);
            c1.setAno(ano);

        Radio r1 = new Radio();
            r1.setEstacao(estacao);
        
        Relogio r2 = new Relogio();
            r2.setHora(hora);
            r2.setMinuto(minuto);

        Temperatura t1 = new Temperatura();
            t1.setTemperatura(temperatura);
        }
}
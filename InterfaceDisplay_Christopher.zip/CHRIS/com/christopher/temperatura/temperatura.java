package com.christopher.temperatura;

public class Temperatura{

	private double temperatura;

	public double getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(double temperatura) {
		this.temperatura = temperatura;
	}
}

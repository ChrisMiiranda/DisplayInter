package com.christopher.temperatura;

import com.christopher.display.display;

public class TempeDisplay extends Display<Temperatura> {
	private TempeFormatter cFormatter = new TempeFormatter();

	private Temperatura temperatura;
	
	//construtor
	public TempeDisplay() {
		this.temperatura = new Temperatura();
		this.temperatura.setTemperatura(25.6);
	}
	
	public void show() {
		System.out.println(cFormatter.formatter(temperatura));
	}
	
}


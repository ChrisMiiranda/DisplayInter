package com.christopher.temperatura;

import com.christopher.display.formatter;

public class tempeFormatter implements Formatter<Temperatura> {

	/**
	 * @see com.christopher.display.formatter#voidformatter(com.christopher.display.T)
	 * 
	 *  
	 */
	public String formatter(Temperatura temperatura) {
		return String.format("%.2f", temperatura.getTemperatura());
	}

}